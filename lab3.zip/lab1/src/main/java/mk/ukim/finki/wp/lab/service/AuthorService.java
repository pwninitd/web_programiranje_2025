package mk.ukim.finki.wp.lab.service;

import mk.ukim.finki.wp.lab.model.Author;
import java.util.List;

public interface AuthorService {
    List<Author> findAll();
    Author findById(Long id);
    Author create(String name, String surname, String biography);
    Author update(Long id, String name, String surname, String biography);
    void delete(Long id);
}
