package mk.ukim.finki.wp.lab.service;

import mk.ukim.finki.wp.lab.model.Book;

import java.util.List;

public interface BookService {
    List<Book> listAll();
    List<Book> searchBooks(String text, Double rating);
    Book getBookById(Long id);
    void update(Long bookId, String title, String genre, Double averageRating, Long authorId);
    void create(String title, String genre, Double averageRating, Long authorId);
    void delete(Long bookId);
}
