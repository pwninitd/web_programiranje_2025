package mk.ukim.finki.wp.lab.service.implementation;

import mk.ukim.finki.wp.lab.model.Author;
import mk.ukim.finki.wp.lab.model.exceptions.AuthorNotFoundException;
import mk.ukim.finki.wp.lab.repository.AuthorRepository;
import mk.ukim.finki.wp.lab.service.AuthorService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AuthorServiceImpl implements AuthorService {

    private final AuthorRepository authorRepository;

    public AuthorServiceImpl(AuthorRepository authorRepository) {
        this.authorRepository = authorRepository;
    }

    @Override
    public List<Author> findAll() {
        return authorRepository.findAll();
    }

    @Override
    public Author findById(Long id) {
        return authorRepository.findById(id)
                .orElseThrow(() -> new AuthorNotFoundException(id.toString()));
    }

    @Override
    public Author create(String name, String surname, String biography) {
        Author author = new Author();
        author.setName(name);
        author.setSurname(surname);
        author.setBiography(biography);
        return authorRepository.save(author);
    }

    @Override
    public Author update(Long id, String name, String surname, String biography) {
        Author author = authorRepository.findById(id)
                .orElseThrow(() -> new AuthorNotFoundException(id.toString()));

        author.setName(name);
        author.setSurname(surname);
        author.setBiography(biography);

        return authorRepository.save(author);
    }

    @Override
    public void delete(Long id) {
        // optionally check existence
        Author author = authorRepository.findById(id)
                .orElseThrow(() -> new AuthorNotFoundException(id.toString()));
        authorRepository.delete(author);
    }
}