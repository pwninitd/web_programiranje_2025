package mk.ukim.finki.wp.lab.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class Author {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String surname;
    private String biography;

    @OneToMany(mappedBy = "author")
    private List<Book> books;

    public Author(String name, String surname, String biography){
        this.name = name;
        this.surname = surname;
        this.biography = biography;
    }

}
