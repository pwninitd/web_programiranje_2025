package mk.ukim.finki.wp.lab.service.implementation;

import mk.ukim.finki.wp.lab.model.Book;
import mk.ukim.finki.wp.lab.model.exceptions.AuthorNotFoundException;
import mk.ukim.finki.wp.lab.model.exceptions.BookNotFoundException;
import mk.ukim.finki.wp.lab.repository.AuthorRepository;
import mk.ukim.finki.wp.lab.repository.BookRepository;
import mk.ukim.finki.wp.lab.service.BookService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookServiceImpl implements BookService {
    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;

    public BookServiceImpl(BookRepository bookRepository, AuthorRepository authorRepository) {
        this.bookRepository = bookRepository;
        this.authorRepository = authorRepository;
    }

    @Override
    public List<Book> listAll() {
        return bookRepository.findAll();
    }

    @Override
    public List<Book> searchBooks(String text, Double rating) {

        return bookRepository.findBooksByTitleContainsAndAverageRatingGreaterThan(text, rating);
    }

    @Override
    public Book getBookById(Long id) {
        return bookRepository.getBookById(id).orElseThrow(() -> new BookNotFoundException(id.toString()));
    }

    @Override
    public void update(Long bookId, String title, String genre, Double averageRating, Long authorId) {
        Book book = bookRepository.getBookById(bookId).orElseThrow(() -> new BookNotFoundException(bookId.toString()));
        book.setTitle(title);
        book.setGenre(genre);
        book.setAverageRating(averageRating);
        book.setAuthor(authorRepository.findById(authorId).orElseThrow(() -> new AuthorNotFoundException(authorId.toString())));
        bookRepository.save(book);
    }

    @Override
    public void create(String title, String genre, Double averageRating, Long authorId) {
        Book book = new Book(title, genre, averageRating, authorRepository.findById(authorId).orElseThrow(() -> new AuthorNotFoundException(authorId.toString())));
        bookRepository.save(book);
    }

    @Override
    public void delete(Long bookId) {
        bookRepository.delete(bookRepository.getBookById(bookId).orElseThrow(() -> new BookNotFoundException(bookId.toString())));
    }
}
