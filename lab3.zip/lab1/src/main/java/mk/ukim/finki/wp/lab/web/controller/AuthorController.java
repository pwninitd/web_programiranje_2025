package mk.ukim.finki.wp.lab.web.controller;

import mk.ukim.finki.wp.lab.model.Author;
import mk.ukim.finki.wp.lab.service.AuthorService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/authors")
public class AuthorController {

    private final AuthorService authorService;

    public AuthorController(AuthorService authorService) {
        this.authorService = authorService;
    }

    // LIST PAGE
    @GetMapping("")
    public String getAuthorsPage(
            @RequestParam(required = false) String error,
            Model model
    ){
        model.addAttribute("authors", authorService.findAll());
        return "listAuthors";
    }

    // ADD FORM
    @GetMapping("/add")
    public String formAddAuthor(Model model) {
        // for consistency in template, can pass empty Author if you want
        // model.addAttribute("author", new Author());
        return "author-form";
    }

    // PROCESS ADD
    @PostMapping("/add")
    public String addAuthor(
            @RequestParam String name,
            @RequestParam String surname,
            @RequestParam String biography
    ) {
        authorService.create(name, surname, biography);
        return "redirect:/authors";
    }

    // EDIT FORM
    @GetMapping("/edit/{id}")
    public String formEditAuthor(@PathVariable Long id, Model model) {
        Author author = authorService.findById(id);
        model.addAttribute("author", author);
        return "author-form";
    }

    // PROCESS EDIT
    @PostMapping("/edit/{id}")
    public String editAuthor(
            @PathVariable Long id,
            @RequestParam String name,
            @RequestParam String surname,
            @RequestParam String biography
    ) {
        authorService.update(id, name, surname, biography);
        return "redirect:/authors";
    }

    // DELETE
    @PostMapping("/delete/{id}")
    public String deleteAuthor(@PathVariable Long id) {
        authorService.delete(id);
        return "redirect:/authors";
    }
}
