package mk.ukim.finki.wp.lab.repository;

import mk.ukim.finki.wp.lab.model.Book;

import java.util.List;

public interface BookRepository {
    public List<Book> findAll();
    public List<Book> searchBooks(String text, Double rating);
}
